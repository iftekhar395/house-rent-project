package houseRentMng;


import java.sql.Connection;
import java.sql.DriverManager;


/**
 *
 * @author Naim
 */
public class Javaconnect {
    
public static Connection ConnecrDb(){
  try{
     Connection conn = null;
             conn = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "123");
     return conn;
  } catch(Exception e){
      e.printStackTrace();
  }
        return null;
}
    
}
