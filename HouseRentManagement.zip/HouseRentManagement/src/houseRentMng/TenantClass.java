/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package houseRentMng;

/**
 *
 * @author R-41
 */
public class TenantClass {
    private String hno;
    private String floor;
    private String unit;
    private String month;
    private int year;
    private double ebill;
    private double wbill;
    private double gbill;
    private double others;
    private double rent;
    private double total;
    private double advance;
    private double due;
    private String name;
    private String contact;

    public String getHno() {
        return hno;
    }

    public void setHno(String hno) {
        this.hno = hno;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getEbill() {
        return ebill;
    }

    public void setEbill(double ebill) {
        this.ebill = ebill;
    }

    public double getWbill() {
        return wbill;
    }

    public void setWbill(double wbill) {
        this.wbill = wbill;
    }

    public double getGbill() {
        return gbill;
    }

    public void setGbill(double gbill) {
        this.gbill = gbill;
    }

    public double getOthers() {
        return others;
    }

    public void setOthers(double others) {
        this.others = others;
    }

    public double getRent() {
        return rent;
    }

    public void setRent(double rent) {
        this.rent = rent;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public double getAdvance() {
        return advance;
    }

    public void setAdvance(double advance) {
        this.advance = advance;
    }

    public double getDue() {
        return due;
    }

    public void setDue(double due) {
        this.due = due;
    }
    
}
